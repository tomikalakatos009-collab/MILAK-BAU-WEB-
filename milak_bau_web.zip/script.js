
// Galéria lightbox
const galleryItems = document.querySelectorAll('.gallery-item');
const lightbox = document.getElementById('lightbox');
const lightboxImg = document.querySelector('.lightbox-content');
const closeBtn = document.querySelector('.close');

galleryItems.forEach(item => {
  item.addEventListener('click', () => {
    lightbox.style.display = 'flex';
    lightboxImg.src = item.src;
  });
});

closeBtn.addEventListener('click', () => {
  lightbox.style.display = 'none';
});

window.addEventListener('click', (e) => {
  if(e.target === lightbox){
    lightbox.style.display = 'none';
  }
});

// Scroll animáció a galéria képeknek
window.addEventListener('scroll', () => {
  const imgs = document.querySelectorAll('.mini-gallery img');
  imgs.forEach(img => {
    const rect = img.getBoundingClientRect();
    if(rect.top < window.innerHeight - 50){
      img.classList.add('visible');
    }
  });
});
